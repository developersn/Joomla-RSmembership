<?php
defined('_JEXEC') or die('Restricted access');

jimport('sncore.include');

class plgSystemSn_rsmembership extends JPlugin
{
	public $_plugin = array();
	public $_params = array();

    function __construct(&$subject,$config)
    {
        parent::__construct($subject,$config);

        if(!$this->canRun())
        {
            return;
        }

        SNGlobal::loadLanguage('plg_system_sn_rsmembership',JPATH_ADMINISTRATOR);

        $portalTitle = $this->params->get('sn_portal_title','');
        if(empty($portalTitle))
        {
            $portalTitle = 'پرداخت آنلاین';
        }

        RSMembership::addPlugin($portalTitle,'sn_rsmembership');
    }

	function canRun()
	{
		$file = JPATH_ADMINISTRATOR.DS.'components'.DS.'com_rsmembership'.DS.'helpers'.DS.'rsmembership.php';

		if(file_exists($file) && !class_exists('RSMembershipHelper'))
        {
            require_once $file;
        }

		if(class_exists('RSMembershipHelper') && class_exists('SNGlobal'))
        {
            return true;
        }
		return false;
	}

	function onMembershipPayment($plugin, $data, $extra, $membership, $transaction)
	{
        $app = JFactory::getApplication();

		$orderId = time();
		$transaction->custom = $orderId;
		$amount = $transaction->price;
		$email = $transaction->user_email;
        $backUrl = JURI::base().'index.php?option=com_rsmembership&snNotify=1';

        $pin = $this->params->get('sn_pin','');
        $currency = $this->params->get('sn_currency','');
        $sendPayerInfo = $this->params->get('sn_send_payer_info','');

        $amount = SNApi::modifyPrice($amount,$currency);

        $data = array(
            'pin'=> $pin,
            'price'=> $amount,
            'callback'=> $backUrl,
            'order_id'=> $orderId,
            'email'=> $email,
            'description'=> '',
            'mobile'=> '',
        );

        list($status,$msg,$resultData) = SNApi::request($data,$sendPayerInfo,'rsmembership');

        if($status == true)
        {
            $data['bank_callback_details'] = $resultData['bank_callback_details'];
            $data['au'] = $resultData['au'];

            SNApi::clearData();
            SNApi::setData($data);

            $html = '<div class="sn-rsmembership-go-to-bank">'.JText::_('SN_CONNECTING_TO_PORTAL').'</div>';
            $html .= SNGlobal::postData($resultData['form_details']['action'],$resultData['form_details']['fields'],100);
            return $html;
        }

        $url = JRoute::_('index.php?option=com_rsmembership&view=membership&cid='.$membership->id);
        $errorMsg = $msg;
        $app->redirect($url,'<h5>'.$errorMsg.'</h5>',$msgType='Error');
	}

    public function onAfterDispatch()
    {
        if(SNGlobal::getVar('snNotify') == 1)
        {
            $this->snMembershipVerify();
        }
    }

    function snMembershipVerify()
    {
        $app = JFactory::getApplication();

        $au = SNGlobal::getVar('au','','none','request');
        $urlOrderId = SNGlobal::getVar('order_id','','none','request');
        $sessionData = SNApi::getData();

        if(!empty($au) && !empty($sessionData) && $sessionData['order_id'] == $urlOrderId)
        {
            $orderId = $sessionData['order_id'];

            if(!empty($orderId))
            {
                $query = "SELECT * FROM `#__rsmembership_transactions` WHERE `custom`='".$orderId."' AND `status`!='completed'";
                $transaction = SNGlobal::selectByQuery($query,2);

                if(!empty($transaction))
                {
                    $bankData = array();
                    foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
                    {
                        $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
                    }

                    $data = array (
                        'pin' => $sessionData['pin'],
                        'price' => $sessionData['price'],
                        'order_id' => $sessionData['order_id'],
                        'au' => $au,
                        'bank_return' => $bankData,
                    );

                    list($status,$msg,$resultData) = SNApi::verify($data,'rsmembership');
                    
                    if($status == true)
                    {
                        $bankAu = !empty($resultData['bank_au']) ? $resultData['bank_au'] : $au;

                        RSMembership::approve($transaction['id']);
                        $query = "UPDATE `#__rsmembership_transactions` SET `hash`='".SNGlobal::escape($bankAu)."' WHERE `custom`='".SNGlobal::escape($orderId)."' LIMIT 1";
                        SNGlobal::update($query);

                        $errorMsg = JText::_('SN_PAID_TRANSACTION');
                        $errorMsg = str_replace('{REF}',$bankAu,$errorMsg);
                        $url = JRoute::_('index.php?option=com_rsmembership&view=mymemberships',false);
                        $app->redirect($url,$errorMsg,'message');
                        return;
                    }
                }
            }
        }

        $errorMsg = JText::_('SN_UNPAID_TRANSACTION');
        $app->enqueueMessage('<h5>'.$errorMsg.'</h5>','error');
    }
}